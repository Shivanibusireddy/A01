Website contains Homepage,Calcute heart Rate,Contact pages
Homepage contains image,video and introduction.
Calculate Heart Rate calculates the maximum number of times heart beats per minute.
Contact has links to my Github,Bitbucket and LinkedIn.

Html tags used:

<html>
<head>
<title>
<body>
<header>
<footer>
<link>
<form>
<br>
<strong>
<input>
<button>
<p>
and some more.






